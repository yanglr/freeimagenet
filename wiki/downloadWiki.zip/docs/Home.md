**This Project aims to improve the outdated .NET wrapper for the [FreeImage Library](http://freeimage.sourceforge.net/index.html).**

This is not an attempt to fully support the FreeImage Library and cover every function and detail, for I do not have the time for that, but simply to improve the wrapper by adding missing functionality as I come across it.

To see what's already done, please take a look at the [changelog](https://freeimagenet.codeplex.com/SourceControl/list/changesets).

**Additional Features**
* Extended support for metadata through the [WICMetadataHandler class](http://argusmagnus.dx.am/freeimagenetdoc/html/T_FreeImageAPI_Metadata_WICMetadataHandler.htm), especially for writing metadata.

If you miss something or want to propose a feature, please [open a Workitem](https://freeimagenet.codeplex.com/WorkItem/Create).


