using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;
//
[assembly: AssemblyTitle("FreeImage.NET")]
[assembly: AssemblyDescription(".NET wrapper for the FreeImage 3.17.0 Library")]
[assembly: AssemblyConfiguration("All")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("FreeImage.NET Wrapper")]
[assembly: AssemblyCopyright("Copyright 2003-2011, FreeImage, DataGis")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: ComVisibleAttribute(false)]
[assembly: NeutralResourcesLanguageAttribute("")]
[assembly: GuidAttribute("64a4c935-b757-499c-ab8c-6110316a9e51")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("3.17.0.5")]
[assembly: AssemblyFileVersionAttribute("3.17.0")]